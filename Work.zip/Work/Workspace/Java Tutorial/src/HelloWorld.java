
public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello World!");
		
		int a = 100;
		
		System.out.println("value of i is : " + a);
		
		String str1 = "Test me!!";
				
		System.out.println("string me : " + str1);
		
	}

}
